package com.francesco.cinema

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import androidx.preference.PreferenceManager
import com.francesco.cinema.databinding.ActivityLoginPagamentoBinding
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginPagamento : AppCompatActivity() {

    private lateinit var binding : ActivityLoginPagamentoBinding
    private val TAG = "Prova"
    private var canLogin = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginPagamentoBinding.inflate(layoutInflater)
        setContentView(binding.root)


        binding.btnLogin.setOnClickListener() {
            val email = binding.emailEditText2.text.toString()
            val password = binding.passwordEditText2.text.toString()

            // Verifica se i campi email e password non sono vuoti
            if (email.isNotEmpty() && password.isNotEmpty()) {
                val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
                val editor = sharedPreferences.edit()
                editor.putString("email", email)
                editor.apply()
                loginUtente(email, password)
            } else {
                Toast.makeText(this, "Inserisci email e password", Toast.LENGTH_SHORT).show()
            }

        }
    }

    private fun loginUtente(email: String, password: String) {

        if (email.isEmpty()) {
            binding.emailEditText2.error =
                "Campo obbligatorio"
            return
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailEditText2.error = "Indirizzo email non valido"
            return
        }

        if (password.isEmpty()) {
            binding.passwordEditText2.error = "Campo obbligatorio"
            return
        } else if (password.length < 5) {
            binding.passwordEditText2.error = "La password deve essere di almeno 5 caratteri"
            return
        }

        Log.i(TAG, "$email, $password")
        val query = "SELECT * FROM webmobile.Utenti WHERE email = '$email' AND password = '$password'"
        RetrofitClient.retrofit.login(query).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    Log.i("AAA", "$result")
                    if (result != null && result.has("queryset")) {
                        val queryset = result.getAsJsonArray("queryset")
                        if (queryset.size() > 0) {
                            val jsonObject = queryset[0].asJsonObject
                            if (jsonObject.has("eliminato")) {
                                val eliminato = jsonObject.get("eliminato").asInt == 1
                                Log.i("eliminato", eliminato.toString())



                                if (eliminato) {

                                    Toast.makeText(this@LoginPagamento, "Account eliminato", Toast.LENGTH_SHORT).show()
                                    canLogin = false
                                    binding.btnLogin.isEnabled = false


                                    val intent = Intent(this@LoginPagamento, MainActivity::class.java)
                                    startActivity(intent)
                                    finish()
                                } else {
                                    canLogin = true
                                    binding.btnLogin.isEnabled = true




                                    if (SessionManager.isLoggedIn()) {

                                        val intent = Intent(this@LoginPagamento, ActivityRiepilogoPag::class.java)
                                        startActivity(intent)
                                        finish()
                                    } else {
                                        val i = Intent(this@LoginPagamento, ActivityRiepilogoPag::class.java)
                                        val email = binding.emailEditText2.text.toString()
                                        i.putExtra("email", email)
                                        SessionManager.setLoggedIn(true)
                                        startActivity(i)
                                    }
                                }
                            }
                        }
                        else {
                            Toast.makeText(this@LoginPagamento, "Dati inseriti non corretti", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this@LoginPagamento, "Risposta del server non valida", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@LoginPagamento, "Dati inseriti non corretti", Toast.LENGTH_SHORT).show()

                }

                // Controllo finale per impedire l'accesso se necessario
                if (!canLogin) {

                    binding.btnLogin.isEnabled = false
                    Toast.makeText(this@LoginPagamento, "Impossibile accedere con un account eliminato", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                Log.e("OnFailure", t.toString())
                Toast.makeText(this@LoginPagamento, "Errore nella risposta del server, riprova più tardi", Toast.LENGTH_SHORT).show()

                if (!canLogin) {

                    binding.btnLogin.isEnabled = false
                    Toast.makeText(this@LoginPagamento, "Impossibile accedere con un account eliminato", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }



}