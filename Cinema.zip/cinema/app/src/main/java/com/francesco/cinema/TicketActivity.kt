package com.francesco.cinema

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.francesco.cinema.databinding.ActivityTicketBinding
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TicketActivity : AppCompatActivity() {

    private lateinit var binding: ActivityTicketBinding
    private lateinit var ticketAdapter: TicketAdapter
    private var idUtenteBiglietto: Int? = null
    private var tickets: List<Ticket> = emptyList() // dichiarazione della lista vuota di biglietti


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTicketBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val ticketList= intent.getSerializableExtra("listaBiglietti") as List<Ticket>
        Log.i("TicketList", "$ticketList")
        ticketAdapter = TicketAdapter(this@TicketActivity)
    ticketAdapter.updateTicket(ticketList)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = ticketAdapter


    }


    private fun cercaIdUtente(email: String, callback: (Int?) -> Unit) {
        val query = "SELECT idUtenti FROM webmobile.Utenti WHERE email = '$email'"
        RetrofitClient.retrofit.login(query).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    if (result != null && result.has("queryset")) {
                        val queryset = result.getAsJsonArray("queryset")
                        if (queryset.size() > 0) {
                            val jsonObject = queryset[0].asJsonObject
                            val idUtente = jsonObject.get("idUtenti").asInt
                            callback(idUtente)
                        } else {
                            callback(null)
                        }
                    } else {
                        callback(null)
                    }
                } else {
                    callback(null)
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                callback(null)
            }
        })
    }

    private fun getTickets(): List<Ticket> {
        val tickets = mutableListOf<Ticket>()
        return tickets
    }





}