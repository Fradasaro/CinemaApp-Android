package com.francesco.cinema


class ServizioPagamentoSimulato : ServizioPagamento {

    override fun processoPagamento(importo: Double, numCartaCredito: String, titolare: String, scadenza: String, cvc: String): Boolean {
        if (!validaNumCartaCredito(numCartaCredito)) {
            return false
        }

        if (!validaTitolare(titolare)) {

            return false
        }

        if (!validaScadenza(scadenza)) {
            return false
        }

        if (!validaCVC(cvc)) {
            return false
        }

        // Genera un numero casuale per simulare il successo o il fallimento del pagamento
        val numeroRandom = (0..10).random()

        // Simula il pagamento
        val pagamentoSuccessful = numeroRandom > 3 // Il pagamento ha il 70% di probabilità di avere successo

        return pagamentoSuccessful


    }

    private fun validaNumCartaCredito(numCartaCredito: String): Boolean {
        return numCartaCredito.length == 16 && numCartaCredito.matches(Regex("\\d+"))
        //Verifica se la lunghezza del numero della carta è esattamente 16 caratteri e L'espressione regolare \\d+ corrisponde a una sequenza di una o più cifre numeriche
    }

    private fun validaTitolare(titolare: String): Boolean {

        return titolare.isNotEmpty()
    }

    private fun validaScadenza(scadenza: String): Boolean {

        return scadenza.matches(Regex("\\d{2}/\\d{2}"))
    }

    private fun validaCVC(cvc: String): Boolean {

        return cvc.length == 3 && cvc.matches(Regex("\\d+"))
    }

}