package com.francesco.cinema

import android.graphics.drawable.BitmapDrawable


data class Film(
    val idFilm: Int,
    val titolo: String,
    val cast: String,
    val durata: String,
    val trama: String,
    val img: String
): java.io.Serializable {
}