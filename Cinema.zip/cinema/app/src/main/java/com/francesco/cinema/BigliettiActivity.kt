package com.francesco.cinema

import android.content.Intent
import android.os.Bundle
import androidx.preference.PreferenceManager
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bumptech.glide.Glide
import com.francesco.cinema.databinding.ActivityBigliettiBinding

class BigliettiActivity : AppCompatActivity() {

    private lateinit var binding: ActivityBigliettiBinding
    private lateinit var filmList: List<Film>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityBigliettiBinding.inflate(layoutInflater)
        setContentView(binding.root)

        filmList = intent.getSerializableExtra("FilmList") as List<Film>

        val filmAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, filmList.map { it.titolo })
        binding.filmSpinner.adapter = filmAdapter

        binding.filmSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View?, position: Int, id: Long) {
                // Recupera il film selezionato dalla lista di film
                val selectedFilm = filmList[position]

                val imageUrl = Constants.BASE_URL + selectedFilm.img

                Glide.with(this@BigliettiActivity).load(imageUrl).into(binding.filmImageView)

                // Aggiorna il nome del film selezionato
                binding.filmNameTextView.text = selectedFilm.titolo
                Log.i("BIGLIETTI", "${selectedFilm.titolo}")
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Non fa nulla
            }
        }

        // Imposta il valore iniziale del NumberPicker
        binding.numBigliettiPicker.value = 1

        // Impostiamo il valore minimo e massimo del NumberPicker per il numero di biglietti
        binding.numBigliettiPicker.minValue = 1
        binding.numBigliettiPicker.maxValue = 10

        // Aggiungiamo l'ascoltatore per aggiornare il prezzo totale quando si cambia il numero di biglietti
        binding.numBigliettiPicker.setOnValueChangedListener { _, _, _ -> updatePrezzoTotale() }

        // Aggiungiamo l'ascoltatore per aggiornare il prezzo totale quando si seleziona/deseleziona la CheckBox 3D
        binding.checkBox3.setOnCheckedChangeListener { _, _ -> updatePrezzoTotale() }

        // Aggiungi l'ascoltatore per l'acquisto dei biglietti
        binding.acquistaButton.setOnClickListener {
            val numBiglietti = binding.numBigliettiPicker.value

            val selectedFilm = filmList[binding.filmSpinner.selectedItemPosition]

            if (numBiglietti <= 0) {
                Toast.makeText(this, "Inserisci un numero di biglietti valido", Toast.LENGTH_SHORT).show()
            } else {
                val prezzoBase = numBiglietti * 10.0
                val prezzoIn3D = if (binding.checkBox3.isChecked) numBiglietti * 3.0 else 0.0
                val prezzoTotale = prezzoBase + prezzoIn3D


                val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
                val editor = sharedPreferences.edit()
                editor.putInt("NumeroBiglietti", numBiglietti)
                editor.putString("TitoloFilm", selectedFilm.titolo)
                editor.putFloat("prezzoBiglietti", prezzoTotale.toFloat())
                editor.apply()




                val message = "Hai acquistato $numBiglietti biglietti per il film ${selectedFilm.titolo} al prezzo di %.2f €".format(prezzoTotale)
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
                val intent = Intent(this, SelezionaDataOraSalaActivity::class.java)
                intent.putExtra("Film", selectedFilm)
                intent.putExtra("num_biglietti", numBiglietti)
                startActivity(intent)
            }
        }

        // Aggiorna il prezzo totale iniziale
        updatePrezzoTotale()
    }

    private fun updatePrezzoTotale() {
        val numBiglietti = binding.numBigliettiPicker.value

        // Calcola il prezzo base dei biglietti
        val prezzoBase = numBiglietti * 10.0

        // Calcola il prezzo aggiuntivo per i biglietti in 3D, se la CheckBox è selezionata
        val prezzoIn3D = if (binding.checkBox3.isChecked) numBiglietti * 3.0 else 0.0

        val prezzoTotale = prezzoBase + prezzoIn3D

        // Aggiorna il testo della TextView con il prezzo totale dei biglietti
        binding.prezzoTextView.text = String.format("%.2f €", prezzoTotale)
    }
}