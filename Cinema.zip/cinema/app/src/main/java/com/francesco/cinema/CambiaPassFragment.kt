package com.francesco.cinema

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import com.francesco.cinema.databinding.FragmentCambiaPassBinding
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response




class CambiaPassFragment : Fragment() {
    private lateinit var binding: FragmentCambiaPassBinding
    private var email: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        email = arguments?.getString("email")
    }




    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        binding = FragmentCambiaPassBinding.inflate(inflater, container, false)

        if (!email.isNullOrEmpty()) {
            binding.btnSalva.setOnClickListener {
                val nuovaPassword = binding.passEditText3.text.toString()
                val confermaNuovaPassword = binding.confermaPassEditText2.text.toString()

                val email = arguments?.getString("email")
                if (!email.isNullOrEmpty() && nuovaPassword.isNotEmpty() && confermaNuovaPassword.isNotEmpty()) {
                    if (nuovaPassword == confermaNuovaPassword) {
                        val query =
                            "UPDATE Utenti SET password = '$nuovaPassword' WHERE email = '$email'"
                        RetrofitClient.retrofit.salvaPassword(query)
                            .enqueue(object : Callback<JsonObject?> {
                                override fun onResponse(
                                    call: Call<JsonObject?>,
                                    response: Response<JsonObject?>
                                ) {
                                    if (response.isSuccessful) {
                                        Toast.makeText(
                                            requireContext(),
                                            "Password salvata",
                                            Toast.LENGTH_SHORT
                                        ).show()

                                    } else {
                                        Toast.makeText(
                                            requireContext(),
                                            "Errore durante il salvataggio della password",
                                            Toast.LENGTH_SHORT
                                        ).show()
                                    }
                                }

                                override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                                    Toast.makeText(
                                        requireContext(),
                                        "Errore nella chiamata API",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                }
                            })
                    } else {
                        Toast.makeText(
                            requireContext(),
                            "Le password non corrispondono",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Inserire la nuova password",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
        return binding.root
    }


}
