package com.francesco.cinema

class Constants {
    companion object {
        const val BASE_URL = "http://10.0.2.2:8000/webmobile/"
    }
}