package com.francesco.cinema
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager
import com.francesco.cinema.Film
import com.francesco.cinema.Proiezione
import com.francesco.cinema.RetrofitClient
import com.francesco.cinema.UserAPI
import com.francesco.cinema.databinding.SelezioneDataOraSalaBinding
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SelezionaDataOraSalaActivity : AppCompatActivity() {

    private lateinit var binding: SelezioneDataOraSalaBinding
    private lateinit var film: Film
    private val userAPI: UserAPI = RetrofitClient.retrofit

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = SelezioneDataOraSalaBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val numBiglietti = intent.getIntExtra("num_biglietti", 0)


        film = intent.getSerializableExtra("Film") as Film

        val proiezioni = queryProiezioni(film) // Esempio di funzione per recuperare le proiezioni dal server





        binding.prenotaButton.setOnClickListener {
            val data = binding.dataSpinner.selectedItem.toString()
            val ora = binding.oraSpinner.selectedItem.toString()
            val sala = binding.salaSpinner.selectedItem as Int
            val proiezione = Proiezione(0, data, ora, film.idFilm, sala)



            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
            val editor = sharedPreferences.edit()
            editor.putInt("Sala", sala) // Sostituisci selectedSala con il valore corretto
            editor.putString("DataProiezione", data)
            editor.putString("OraProiezione", ora)
            editor.apply()




            val intent = Intent(this, PostoActivity::class.java).apply {
                putExtra("num_biglietti", numBiglietti)
                putExtra("Proiezione", proiezione)
            }

            startActivity(intent)
        }
    }

    private fun queryProiezioni(film: Film) {
        val query = "SELECT * FROM webmobile.proiezione WHERE ref_f = ${film.idFilm}"

        userAPI.login(query).enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                if (response.isSuccessful) {
                    val jsonArray = response.body()?.get("queryset") as JsonArray
                    val proiezioni = mutableListOf<Proiezione>()

                    jsonArray?.forEach { jsonObj ->
                        val idProiezione = jsonObj.getAsJsonObject().get("idProiezione")?.asInt ?: 0
                        val dataProiezione = jsonObj.getAsJsonObject().get("data_proiezione")?.asString ?: ""
                        val oraInizio = jsonObj.getAsJsonObject().get("ora_inizio")?.asString ?: ""
                        val refF = jsonObj.getAsJsonObject().get("ref_f")?.asInt ?: 0
                        val refS = jsonObj.getAsJsonObject().get("ref_s")?.asInt ?: 0

                        val proiezione = Proiezione(idProiezione, dataProiezione, oraInizio, refF, refS)
                        proiezioni.add(proiezione)
                    }

                    popolaDataSpinner(proiezioni)
                    popolaOraSpinner(proiezioni)
                    popolaSalaSpinner(proiezioni)
                } else {
                    Toast.makeText(
                        this@SelezionaDataOraSalaActivity,
                        "Errore durante il recupero delle informazioni sulla proiezione",
                        Toast.LENGTH_SHORT
                    ).show()
                    Log.e("HTTP Error", "${response.code()}: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                // Visualizza un messaggio di errore
                Toast.makeText(
                    this@SelezionaDataOraSalaActivity,
                    "Errore durante il recupero delle informazioni sulla proiezione",
                    Toast.LENGTH_SHORT
                ).show()
                Log.e("HTTP Error", t.message ?: "Unknown error")
            }
        })
    }





    private fun popolaDataSpinner(proiezioni: List<Proiezione>) {
        val datiProiezioni = proiezioni.map { it.data_proiezione }.distinct().sorted()

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, datiProiezioni)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.dataSpinner.adapter = adapter
    }

    private fun popolaOraSpinner(proiezioni: List<Proiezione>) {
        val oreProiezioni = proiezioni.map { it.ora_inizio }.distinct().sorted()

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, oreProiezioni)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.oraSpinner.adapter = adapter
    }

    private fun popolaSalaSpinner(proiezioni: List<Proiezione>) {
        val saleProiezioni = proiezioni.map { it.ref_s }.distinct().sorted()

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, saleProiezioni)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.salaSpinner.adapter = adapter
    }
}