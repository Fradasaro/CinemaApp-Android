package com.francesco.cinema

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.francesco.cinema.databinding.ItemRecensioniBinding

class RecensioneAdapter(private var recensioni: List<Recensione>) :
    RecyclerView.Adapter<RecensioneAdapter.RecensioneViewHolder>() {

    // Metodo per aggiornare la lista di recensioni
    fun updateRecensioni(newRecensioni: List<Recensione>) {
        recensioni = newRecensioni
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecensioneViewHolder {
        val binding = ItemRecensioniBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return RecensioneViewHolder(binding)
    }

    override fun onBindViewHolder(holder: RecensioneViewHolder, position: Int) {
        val currentRecensione = recensioni[position]
        holder.bind(currentRecensione)
    }

    override fun getItemCount() = recensioni.size

    inner class RecensioneViewHolder(private val binding: ItemRecensioniBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(recensione: Recensione) {
            binding.textViewReviewText.text = recensione.recensione
            binding.textViewReviewAuthor.text = recensione.recensore
            binding.ratingBarReview.rating = recensione.rating.toFloat()
        }
    }
}
