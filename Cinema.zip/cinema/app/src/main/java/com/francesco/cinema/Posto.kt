package com.francesco.cinema

class Posto(val fila: String, val colonna: String)