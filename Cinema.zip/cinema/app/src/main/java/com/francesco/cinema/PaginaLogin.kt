package com.francesco.cinema

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.service.autofill.UserData
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.Patterns //per Patterns.EMAIL_ADDRESS
import android.widget.Toast
import com.francesco.cinema.databinding.ActivityPaginaLoginBinding
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit

class PaginaLogin : AppCompatActivity() {

    private lateinit var  binding: ActivityPaginaLoginBinding
    private val TAG = "Prova"
    private var canLogin = true



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPaginaLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnRegistrati2.setOnClickListener() {
            val i = Intent(this@PaginaLogin, RegistraAccount::class.java)
            startActivity(i)
        }

        binding.haiDimPassText.setOnClickListener() {
            val i = Intent(this@PaginaLogin, PasswordDimenticata::class.java)
            startActivity(i)
        }


        binding.btnLogin.setOnClickListener() {
            val email = binding.emailEditText2.text.toString()
            val password = binding.passwordEditText2.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                loginUtente(email, password)
            } else {
                Toast.makeText(this, "Inserisci email e password", Toast.LENGTH_SHORT).show()
            }

        }

    }

    private fun loginUtente(email: String, password: String) {

        if (email.isEmpty()) {
            binding.emailEditText2.error =
                "Campo obbligatorio"
            return
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailEditText2.error = "Indirizzo email non valido"
            return
        }

        if (password.isEmpty()) {
            binding.passwordEditText2.error = "Campo obbligatorio"
            return
        } else if (password.length < 5) {
            binding.passwordEditText2.error = "La password deve essere di almeno 5 caratteri"
            return
        }

        Log.i(TAG, "$email, $password")
        val query = "SELECT * FROM webmobile.Utenti WHERE email = '$email' AND password = '$password'"
        RetrofitClient.retrofit.login(query).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    Log.i("AAA", "$result")
                    if (result != null && result.has("queryset")) {
                        val queryset = result.getAsJsonArray("queryset")
                        if (queryset.size() > 0) {
                            val jsonObject = queryset[0].asJsonObject
                            if (jsonObject.has("eliminato")) {
                                val eliminato = jsonObject.get("eliminato").asInt == 1
                                Log.i("eliminato", eliminato.toString())


                                if (eliminato) {

                                        Toast.makeText(this@PaginaLogin, "Account eliminato", Toast.LENGTH_SHORT).show()
                                    canLogin = false
                                    binding.btnLogin.isEnabled = false


                                    val intent = Intent(this@PaginaLogin, MainActivity::class.java)
                                    startActivity(intent)
                                    finish()
                                } else {
                                    canLogin = true
                                    binding.btnLogin.isEnabled = true

                                    if (SessionManager.isLoggedIn()) {
                                        val intent = Intent(this@PaginaLogin, VisualizzaAccount::class.java)
                                        startActivity(intent)
                                        finish()
                                    } else {
                                        val i = Intent(this@PaginaLogin, VisualizzaAccount::class.java)
                                        val email = binding.emailEditText2.text.toString()
                                        i.putExtra("email", email)
                                        SessionManager.setLoggedIn(true)
                                        startActivity(i)
                                    }
                                }
                            }
                        }


                        else {
                            Toast.makeText(this@PaginaLogin, "Dati inseriti non corretti", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Toast.makeText(this@PaginaLogin, "Risposta del server non valida", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@PaginaLogin, "Dati inseriti non corretti", Toast.LENGTH_SHORT).show()

                }

                if (!canLogin) {

                        binding.btnLogin.isEnabled = false
                        Toast.makeText(this@PaginaLogin, "Impossibile accedere con un account eliminato", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                Log.e("OnFailure", t.toString())
                    Toast.makeText(this@PaginaLogin, "Errore nella risposta del server, riprova più tardi", Toast.LENGTH_SHORT).show()

                if (!canLogin) {

                        binding.btnLogin.isEnabled = false
                        Toast.makeText(this@PaginaLogin, "Impossibile accedere con un account eliminato", Toast.LENGTH_SHORT).show()
                }
            }
        })
    }



}