package com.francesco.cinema

import android.content.Intent
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.load.engine.DiskCacheStrategy
import com.francesco.cinema.databinding.ItemFilmBinding

class FilmAdapter(private val films: List<Film>) : RecyclerView.Adapter<FilmAdapter.FilmViewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FilmViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val binding = ItemFilmBinding.inflate(layoutInflater, parent, false)
        return FilmViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FilmViewHolder, position: Int) {
        val currentFilm = films[position]
        holder.bind(currentFilm)
        Log.e("FilmAdapter", "Associazione dati film: $currentFilm")

        Log.i("FilmAdapter", "Binding data to view for film ${currentFilm.titolo}")
        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, FilmDetailsActivity::class.java)

            intent.putExtra("film_id", currentFilm.idFilm)
            holder.itemView.context.startActivity(intent)
        }
    }

    override fun getItemCount(): Int {
        Log.i("FilmAdapter", "getItemCount called with ${films.size} items")
        return films.size
    }

    inner class FilmViewHolder(private val binding: ItemFilmBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(film: Film) {
            binding.textViewFilmTitle.text = film.titolo
            binding.textViewFilmDescription.text = film.cast
            if (film.img.isNotEmpty()) {
                Glide.with(binding.imageViewFilm)
                    //utilizziamo base url perchè solo con film.img non va, visto che è solo il percorso
                    .load(Constants.BASE_URL + film.img)
                    .centerCrop()
                    .into(binding.imageViewFilm)
            } else {
                Glide.with(binding.imageViewFilm)
                    .load(R.drawable.dune)
                    .centerCrop()
                    .into(binding.imageViewFilm)
            }
        }
    }
}

