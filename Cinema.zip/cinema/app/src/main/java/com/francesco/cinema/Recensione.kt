package com.francesco.cinema

data class Recensione(
    val idRecensione: Int,
    val recensione: String,
    val recensore: String,
    val refFilm: Int,
    val rating: Int
): java.io.Serializable