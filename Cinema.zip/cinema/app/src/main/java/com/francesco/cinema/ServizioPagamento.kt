package com.francesco.cinema

interface ServizioPagamento {
    fun processoPagamento (importo: Double, numCartaCredito: String, titolare: String, scadenza: String, cvc: String): Boolean
}