package com.francesco.cinema

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import android.app.AlertDialog
import android.content.DialogInterface
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import android.content.Context
import android.content.SharedPreferences
import android.text.Editable
import android.text.TextWatcher
import android.util.Patterns
import android.view.MotionEvent
import com.francesco.cinema.databinding.ActivityVisualizzaAccountBinding


class VisualizzaAccount : AppCompatActivity() {
private lateinit var into: Intent
    private lateinit var binding: ActivityVisualizzaAccountBinding
    private var modificato = false
    private var IdUtenteCorrente: Int? = null
    private lateinit var email: String

    companion object {
        private const val SHARED_PREFS_FILE_NAME = "my_app_shared_prefs"
        private const val CHIAVE_USERNAME = "username"
        private const val CHIAVE_PASSWORD = "password"
        private const val CHIAVE_EMAIL = "email"
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityVisualizzaAccountBinding.inflate(layoutInflater)
        setContentView(binding.root)


        // Recupera l'email dall'intent
         email = intent.getStringExtra("email").toString()
        if (email != null) {
            getUtenteData(email)
        } else {
            Toast.makeText(this, "Errore", Toast.LENGTH_SHORT).show()

        }

        binding.btnLogout.setOnClickListener() {
            logout()
        }

        binding.btnEliminaAccount.setOnClickListener() {

            mostraDialogConferma()
        }

        binding.btnModifica.setOnClickListener() {

            if (!modificato) {
                val usernameCorrente = binding.usernameEditTex4.text.toString()
                val emailCorrente = binding.emailEditTextAccount.text.toString()
                val passwordCorrente = binding.passwordPlainText.text.toString()

                cercaIdUtente(usernameCorrente, emailCorrente, passwordCorrente)



            } else {

                val nuovoUsername = binding.usernameEditTex4.text.toString()
                val nuovoEmail = binding.emailEditTextAccount.text.toString()
                val nuovoPassword = binding.passwordPlainText.text.toString()


                if (nuovoUsername.isNotEmpty() && nuovoEmail.isNotEmpty() && nuovoPassword.isNotEmpty()) {
                    aggiornaAccount(nuovoUsername, nuovoEmail, nuovoPassword)

                } else {
                    Toast.makeText(this, "Inserisci tutti i campi", Toast.LENGTH_SHORT).show()
                }
                // Disabilita la modifica dei campi di input
                setEditMode(false)

                binding.btnModifica.text = "Modifica account"
                modificato = false


            }
        }


        binding.usernameEditTex4.setOnClickListener {
            if (!modificato) {
                Toast.makeText(this@VisualizzaAccount, "Clicca su Modifica Account per modificare i dati", Toast.LENGTH_SHORT).show()
            }
        }

        binding.emailEditTextAccount.setOnClickListener {
            if (!modificato) {
                Toast.makeText(this@VisualizzaAccount, "Clicca su Modifica Account per modificare i dati", Toast.LENGTH_SHORT).show()
            }
        }

        binding.passwordPlainText.setOnClickListener() {
            if (!modificato) {
                Toast.makeText(this@VisualizzaAccount, "Clicca su Modifica Account per modificare i dati", Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnBigliettiAccount.setOnClickListener(){
           val idUtenti = cercaIdUtente2(email) { idUtente ->
                if (idUtente != null) {
                    Log.i("Prova2", "$idUtente")
                    val userAPI: UserAPI = RetrofitClient.retrofit

                    val query = "SELECT * FROM webmobile.biglietti WHERE ref_utente_b = $idUtente"

                    userAPI.login(query).enqueue(object : Callback<JsonObject> {
                        override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                            if (response.isSuccessful) {
                                val result = response.body()
                                val jsonArray = result?.getAsJsonArray("queryset")
                                Log.d("TicketActivity", "Numero di biglietti: ${jsonArray?.size()}")
                                val ticketList = mutableListOf<Ticket>()
                                jsonArray?.forEach { jsonObj ->
                                    val ticket = Ticket(
                                        idTicket = jsonObj.asJsonObject.get("idTicket").asInt,
                                        data_proiezione = jsonObj.asJsonObject.get("data_proiezione").asString,
                                        ora_inizio = jsonObj.asJsonObject.get("ora_inizio").asString,
                                        fila = jsonObj.asJsonObject.get("fila").asString,
                                        colonna = jsonObj.asJsonObject.get("colonna").asString,
                                        ref_film = jsonObj.asJsonObject.get("ref_film").asString,
                                        ref_sala = jsonObj.asJsonObject.get("ref_sala").asInt,
                                        prezzo = jsonObj.asJsonObject.get("prezzo").asDouble,
                                        codice = jsonObj.asJsonObject.get("codice").asString
                                    )
                                    ticketList.add(ticket)
                                }

                                Log.i("Response", "Biglietti caricate: $ticketList")
                                into = Intent(this@VisualizzaAccount, TicketActivity::class.java)
                                into.putExtra("listaBiglietti", ticketList as java.io.Serializable)
                                into.putExtra("email", email)
                                startActivity(into)

                            } else {
                                Log.d("TicketActivity", "Errore nella richiesta della lista di biglietti ${response.code()}")
                            }
                        }

                        override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                            Log.d("TicketActivity", "Errore nella richiesta della lista di biglietti: ${t.message}")
                        }
                    })
                }
            }
            Log.i("Provaa", "$idUtenti")

        }



    }


    private fun cercaIdUtente2(email: String, callback: (Int?) -> Unit) {
        val query = "SELECT idUtenti FROM webmobile.Utenti WHERE email = '$email'"
        RetrofitClient.retrofit.login(query).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    if (result != null && result.has("queryset")) {
                        val queryset = result.getAsJsonArray("queryset")
                        if (queryset.size() > 0) {
                            val jsonObject = queryset[0].asJsonObject
                            val idUtente = jsonObject.get("idUtenti").asInt
                            callback(idUtente)
                        } else {
                            // Nessun utente trovato con l'email specificata
                            callback(null)
                        }
                    } else {
                        callback(null)
                    }
                } else {
                    callback(null)
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                callback(null)
            }
        })
    }

    private fun getUtenteData(email: String) {
        val query = "SELECT username, password FROM webmobile.Utenti WHERE email = '$email'"
        Log.i("verifica", "${email}")
        RetrofitClient.retrofit.getDatiUtenti(query).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()

                    val responseBody = result.toString()
                    Log.i("VisualizzaAccount", "Corpo della risposta: $responseBody")
                    if (result != null) {

                        val querySet = result.getAsJsonArray("queryset")
                        if (querySet != null && querySet.size() > 0) {


                            val userData = querySet[0].asJsonObject
                            val username = userData.get("username")?.asString
                            val password = userData.get("password")?.asString

                            Log.i("verifica usename e password", "$username, $password")

                            if (!username.isNullOrEmpty() && !password.isNullOrEmpty()) {
                                binding.emailEditTextAccount.setText(email)
                                binding.usernameEditTex4.setText(username)
                                binding.passwordPlainText.setText(password)
                            } else {
                                Log.e("VisualizzaAccount", "I dati di username o password sono nulli: ${response.code()}")

                                Toast.makeText(this@VisualizzaAccount, "I dati dell'utente sono nulli o vuoti", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            Log.e("VisualizzaAccount", "La risposta del server non contiene dati validi: : ${response.code()}")
                            Toast.makeText(this@VisualizzaAccount, "I dati dell'utente sono nulli o vuoti", Toast.LENGTH_SHORT).show()
                        }
                    } else {
                        Log.e("VisualizzaAccount", "La risposta del server è null")
                        Toast.makeText(this@VisualizzaAccount, "La risposta del server non contiene dati", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e("VisualizzaAccount", "Errore nella risposta del server: ${response.code()}")
                    Toast.makeText(this@VisualizzaAccount, "Errore nel recupero dei dati", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                Log.e("OnFailure", t.toString())
                Toast.makeText(this@VisualizzaAccount, "Errore nella risposta del server, riprova più tardi", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun logout() {

        val usernameCorrente = binding.usernameEditTex4.text.toString()
        val emailCorrente = binding.emailEditTextAccount.text.toString()
        val passwordCorrente = binding.passwordPlainText.text.toString()

        cercaIdUtente(usernameCorrente, emailCorrente, passwordCorrente)

        val idUtenti = IdUtenteCorrente ?: return
        Log.i("Id dentro aggiorna account", "$idUtenti")
        val isLogged = 0 // false
        aggiornaStatoLogin(idUtenti, isLogged)


        cancellaAuthTokens(this)
        pulisciCache()



        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK
        startActivity(intent)
        finish()
    }

    private fun cancellaAuthTokens(context: Context) {
        val sharedPreferences =
            context.getSharedPreferences(SHARED_PREFS_FILE_NAME, Context.MODE_PRIVATE)

        sharedPreferences.edit()
            .remove(CHIAVE_USERNAME)
            .remove(CHIAVE_EMAIL)
            .remove(CHIAVE_PASSWORD)
            .apply()
    }

    private fun pulisciCache() {
        val sharedPreferences = getSharedPreferences("AppCache", Context.MODE_PRIVATE)
        sharedPreferences.edit().clear().apply()
        SessionManager.setLoggedIn(false)


    }

    private fun eliminaAccount(username: String, email: String, password: String) {
        val query = "UPDATE webmobile.Utenti SET eliminato = 1 WHERE username = '$username' AND email = '$email' AND password = '$password'"
        RetrofitClient.retrofit.eliminaDati(query).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {

                    cancellaAuthTokens(this@VisualizzaAccount)
                    pulisciCache()

                    Toast.makeText(this@VisualizzaAccount, "Account Eliminato!", Toast.LENGTH_SHORT).show()

                    val intent = Intent(this@VisualizzaAccount, MainActivity::class.java)
                    startActivity(intent)
                    finish()


                } else {
                    Toast.makeText(this@VisualizzaAccount, "Errore durante l'eliminazione dell'account", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                Log.e("OnFailure", t.toString())
                Toast.makeText(this@VisualizzaAccount, "Errore nella risposta del server, riprova più tardi", Toast.LENGTH_SHORT).show()
            }
        })
    }



    fun setEditMode(enabled: Boolean) {
        binding.usernameEditTex4.isFocusableInTouchMode  = enabled
        binding.emailEditTextAccount.isFocusableInTouchMode  = enabled
        binding.passwordPlainText.isFocusableInTouchMode  = enabled
    }



    private fun aggiornaAccount(nuovoUsername: String, nuovoEmail: String, nuovoPassword: String) {


        if (nuovoUsername.isEmpty()) {
            binding.usernameEditTex4.error = "Campo obbligatorio"
            return
        }

        if (nuovoEmail.isEmpty()) {
            binding.emailEditTextAccount.error =
                "Campo obbligatorio"
            return
        } else if (!Patterns.EMAIL_ADDRESS.matcher(nuovoEmail).matches()) {
            binding.emailEditTextAccount.error = "Indirizzo email non valido"
            return
        }

        if (nuovoPassword.isEmpty()) {
            binding.passwordPlainText.error = "Campo obbligatorio"
            return
        } else if (nuovoPassword.length < 5) {
            binding.passwordPlainText.error = "La password deve essere di almeno 5 caratteri"
            return
        }

        val idUtenti = IdUtenteCorrente ?: return
        Log.i("Id dentro aggiorna account", "$idUtenti")


        val query = "UPDATE webmobile.Utenti SET username = '$nuovoUsername', email = '$nuovoEmail', password = '$nuovoPassword' WHERE idUtenti = $idUtenti"

        RetrofitClient.retrofit.modificaAccount(query).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()

                    val responseBody = result.toString()
                    Log.i("Modifica account", "Corpo della risposta: $responseBody")

                    Toast.makeText(this@VisualizzaAccount, "Account Aggiornato!", Toast.LENGTH_SHORT).show()

                    setEditMode(false)

                    binding.btnModifica.text = "Modifica account"
                    modificato = false



                } else {
                    Toast.makeText(this@VisualizzaAccount, "Errore durante l'aggiornamento dell'account", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                Log.e("OnFailure", t.toString())
                Toast.makeText(this@VisualizzaAccount, "Errore nella risposta del server, riprova più tardi", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun cercaIdUtente(usernameCorrente: String, emailCorrente: String, passwordCorrente: String) {

        val getIdQuery = "SELECT idUtenti FROM webmobile.Utenti WHERE username = '$usernameCorrente' AND email = '$emailCorrente' AND password = '$passwordCorrente'"
        Log.i("verifica id", "$usernameCorrente, $emailCorrente, $passwordCorrente")
        RetrofitClient.retrofit.getIdUtente(getIdQuery).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    val idUtenteArray = result?.getAsJsonArray("queryset")
                    Log.i("risposta cerca id", "$result. $idUtenteArray")
                    if (idUtenteArray != null && idUtenteArray.size() > 0) {
                        val idUtenteObject = idUtenteArray.get(0).asJsonObject
                        val idUtenti = idUtenteObject.getAsJsonPrimitive("idUtenti")?.asInt
                        if (idUtenti != null) {
                            IdUtenteCorrente = idUtenti
                            Log.i("Id dentro cerca id", "$idUtenti")

                            setEditMode(true)

                            binding.btnModifica.text = "Salva"
                            modificato = true


                        } else {
                            Toast.makeText(this@VisualizzaAccount, "Utente non trovato nel database", Toast.LENGTH_SHORT).show()
                        }
                    }else {
                        Toast.makeText(this@VisualizzaAccount, "Nessun utente trovato nel database", Toast.LENGTH_SHORT).show()
                    }

                } else {
                    Toast.makeText(this@VisualizzaAccount, "Errore durante il recupero dell'ID dell'utente", Toast.LENGTH_SHORT).show()
                    return
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                Log.e("OnFailure", t.toString())
                Toast.makeText(this@VisualizzaAccount, "Errore nella risposta del server, riprova più tardi", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun mostraDialogConferma() {
        val alertDialogBuilder = AlertDialog.Builder(this)
        alertDialogBuilder.setTitle("Eliminare l'account")
        alertDialogBuilder.setMessage("Sei sicuro di voler eliminare il tuo account?")
        alertDialogBuilder.setPositiveButton("Conferma") { dialog, which ->
            val username = binding.usernameEditTex4.text.toString()
            val email = binding.emailEditTextAccount.text.toString()
            val password = binding.passwordPlainText.text.toString()

            if (username.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
                eliminaAccount(username, email, password)
            } else {
                Toast.makeText(this, "Errore!", Toast.LENGTH_SHORT).show()
            }
        }
        alertDialogBuilder.setNegativeButton("Annulla", null)

        val alertDialog = alertDialogBuilder.create()
        alertDialog.show()
    }

    private fun aggiornaStatoLogin(idUtenti: Int, isLogged: Int) {
        Log.i("id, stato", "$idUtenti, $isLogged")
        val query = "UPDATE webmobile.Utenti SET isLogged = $isLogged WHERE id = '$idUtenti'"
        RetrofitClient.retrofit.aggiornaStatoLogin(query).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    val responseBody = result.toString()
                    if (result != null && result.has("queryset")) {
                        val queryset = result.getAsJsonArray("queryset")
                        Log.i("Modifica account", "Corpo della risposta: $responseBody")
                        Toast.makeText(this@VisualizzaAccount, "Aggiornamento stato login", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@VisualizzaAccount, "Risposta dal server non valida", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@VisualizzaAccount, "Aggiornamento stato login non eseguito", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                Log.e("OnFailure", t.toString())
                Toast.makeText(this@VisualizzaAccount, "Errore nella risposta del server, riprova più tardi", Toast.LENGTH_SHORT).show()
            }
        })
    }


    private fun caricaBiglietti() {
        val userAPI: UserAPI = RetrofitClient.retrofit
        val idUtenti = IdUtenteCorrente ?: return
        val query = "SELECT * FROM webmobile.biglietti WHERE ref_utente_b = $idUtenti"

        userAPI.login(query).enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    val jsonArray = result?.getAsJsonArray("queryset")
                    Log.d("TicketActivity", "Numero di biglietti: ${jsonArray?.size()}")
                    val ticketList = mutableListOf<Ticket>()
                    jsonArray?.forEach { jsonObj ->
                        val ticket = Ticket(
                            idTicket = jsonObj.asJsonObject.get("idTicket").asInt,
                            data_proiezione = jsonObj.asJsonObject.get("data_proiezione").asString,
                            ora_inizio = jsonObj.asJsonObject.get("ora_inizio").asString,
                            fila = jsonObj.asJsonObject.get("fila").asString,
                            colonna = jsonObj.asJsonObject.get("colonna").asString,
                            ref_film = jsonObj.asJsonObject.get("ref_film").asString,
                            ref_sala = jsonObj.asJsonObject.get("ref_sala").asInt,
                            prezzo = jsonObj.asJsonObject.get("prezzo").asDouble,
                            codice = jsonObj.asJsonObject.get("codice").asString
                        )
                        ticketList.add(ticket)
                    }

                    Log.i("Response", "Biglietti caricate: $ticketList")
                    into = Intent(this@VisualizzaAccount, TicketActivity::class.java)
                    into.putExtra("listaBiglietti", ticketList as java.io.Serializable)
                    into.putExtra("email", email)
                    startActivity(into)

                } else {
                    Log.d("TicketActivity", "Errore nella richiesta della lista di biglietti ${response.code()}")
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.d("TicketActivity", "Errore nella richiesta della lista di biglietti: ${t.message}")
            }
        })
    }

}