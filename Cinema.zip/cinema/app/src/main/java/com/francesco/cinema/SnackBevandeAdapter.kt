package com.francesco.cinema

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.squareup.picasso.Picasso
import com.francesco.cinema.databinding.SnackBevandeBinding
import com.francesco.cinema.databinding.SnackBevandeItemBinding

class SnackBevandeAdapter(private val context: Context) : RecyclerView.Adapter<SnackBevandeAdapter.SnackBevandeViewHolder>() {
    private var totaleCarrello = 0.0  // variabile per tenere traccia del totale del carrello
    private val quantitaList = mutableListOf<Int>()
    private var snackBevandeList = mutableListOf<SnackBevande>()

    init {
        for (i in 0..10) {
            quantitaList.add(i)
        }
    }

    fun updateSnackBevande(newList: List<SnackBevande>) {
        snackBevandeList.clear()
        snackBevandeList.addAll(newList)
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): SnackBevandeViewHolder {
        val binding = SnackBevandeItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return SnackBevandeViewHolder(binding)
    }

    override fun onBindViewHolder(holder: SnackBevandeViewHolder, position: Int) {
        val snackBevande = snackBevandeList[position]
        holder.bind(snackBevande)
    }

    override fun getItemCount(): Int {
        return snackBevandeList.size
    }

    fun getItem(position: Int): SnackBevande {
        return snackBevandeList[position]
    }

    inner class SnackBevandeViewHolder(val binding: SnackBevandeItemBinding) : RecyclerView.ViewHolder(binding.root) {
        var selectedSnackBevanda: SnackBevande? = null

        fun bind(snackBevande: SnackBevande) {
            binding.snackBevandaNome.text = snackBevande.nome
            binding.snackBevandaPrezzo.text = snackBevande.prezzo.toString() + " €"

            val imageUrl = Constants.BASE_URL + snackBevande.imgSB
            Glide.with(binding.root).load(imageUrl).into(binding.snackBevandaImage)

            val quantitaAdapter = ArrayAdapter(context, android.R.layout.simple_spinner_item, quantitaList)
            quantitaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            binding.snackBevandaSpinnerQuantita.adapter = quantitaAdapter

            binding.snackBevandaSpinnerQuantita.setSelection(snackBevande.quantita - 1)

            binding.snackBevandaSpinnerQuantita.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                    snackBevande.quantita = quantitaList[pos]

                    // Aggiorna il totale del carrello
                    totaleCarrello = calcolaTotaleCarrello()

                    // Notifica l'attività del cambiamento del totale del carrello
                    (context as SnackBevandeActivity).aggiornaTotaleCarrello(totaleCarrello)
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {
                    // Non fare niente
                }
            })
        }
    }

    fun calcolaTotaleCarrello(): Double {
        totaleCarrello = 0.0
        for (snackBevande in snackBevandeList) {
            totaleCarrello += snackBevande.prezzo * snackBevande.quantita
        }
        return totaleCarrello
    }
}