package com.francesco.cinema


import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.preference.PreferenceManager
import android.util.Log
import android.widget.Toast
import com.francesco.cinema.databinding.ActivityRiepilogoPagBinding
import com.google.gson.Gson

import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ActivityRiepilogoPag : AppCompatActivity() {


    private lateinit var binding : ActivityRiepilogoPagBinding
    private var idUtentePagamento: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRiepilogoPagBinding.inflate(layoutInflater)
        setContentView(binding.root)



        // Recupera i dati dalle SharedPreferences
        val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this@ActivityRiepilogoPag)
        val sharedPreferences2 = getSharedPreferences("prezzo_snack", Context.MODE_PRIVATE)
        val numeroBiglietti = sharedPreferences.getInt("NumeroBiglietti", 0)
        val titoloFilm = sharedPreferences.getString("TitoloFilm", null)?: ""
        val sala = sharedPreferences.getInt("Sala", 0  )
        val dataProiezione = sharedPreferences.getString("DataProiezione", null)?: ""
        val oraProiezione = sharedPreferences.getString("OraProiezione", null)?: ""
        val prezzoBiglietti = sharedPreferences.getFloat("prezzoBiglietti", 0.0F).toDouble()
        val postiSelezionatiJson = sharedPreferences.getString("posti_selezionati", null)
        val type = object : TypeToken<List<Posto>>() {}.type
        val postiSelezionati = Gson().fromJson<List<Posto>>(postiSelezionatiJson, type) ?: mutableListOf()
        val totaleCarrelloSnack = sharedPreferences2.getFloat("totaleCarrello", 0.0F).toDouble()


        val email = sharedPreferences.getString("email", null)?: ""
        if (email != null) {
            cercaIdUtente(email)
        } else {
            Toast.makeText(this, "Errore", Toast.LENGTH_SHORT).show()
            return
        }





        binding.snackRiep.text = String.format("%.2f €", totaleCarrelloSnack)

        binding.filmTextRiep.text = titoloFilm.toString()
        binding.nBigliettoRiep.text = numeroBiglietti.toString()
        binding.prezzoBigliettoRiep.text = String.format("%.2f €", prezzoBiglietti )
        binding.salaTextRiepilogo.text = sala.toString()

        val prezzoTotAcquisto = totaleCarrelloSnack  + prezzoBiglietti
        binding.totRiep.text = String.format("%.2f €", prezzoTotAcquisto)
        val editor = sharedPreferences.edit()
        editor.putFloat("totale", prezzoTotAcquisto.toFloat())

        binding.btnRiep.setOnClickListener(){
            inserisciBiglietto(postiSelezionati, dataProiezione, oraProiezione, titoloFilm, sala, prezzoBiglietti, )
            val i = Intent(this, ActivityPagamento::class.java)
            intent.putExtra("importo", prezzoTotAcquisto)
            startActivity(i)
        }

    }





    private fun cercaIdUtente(email: String) {

        // Recupera l'ID dell'utente corrente dal database
        val getIdQuery = "SELECT idUtenti FROM webmobile.Utenti WHERE email = '$email'"
        Log.i("verifica id", "$email")
        RetrofitClient.retrofit.getIdUtente(getIdQuery).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    val idUtenteArray = result?.getAsJsonArray("queryset")
                    Log.i("risposta cerca id", "$result. $idUtenteArray")
                    if (idUtenteArray != null && idUtenteArray.size() > 0) {
                        val idUtenteObject = idUtenteArray.get(0).asJsonObject
                        val idUtenti = idUtenteObject.getAsJsonPrimitive("idUtenti")?.asInt
                        if (idUtenti != null) {
                            Log.i("Id dentro cerca id", "$idUtenti")
                            idUtentePagamento = idUtenti

                        } else {
                            // L'utente corrente non è stato trovato nel database
                            Toast.makeText(this@ActivityRiepilogoPag, "Utente non trovato nel database", Toast.LENGTH_SHORT).show()
                        }
                    }else {
                        // Nessun utente trovato nel database
                        Toast.makeText(this@ActivityRiepilogoPag, "Nessun utente trovato nel database", Toast.LENGTH_SHORT).show()
                    }

                } else {
                    // Errore durante la query per ottenere l'ID dell'utente
                    Toast.makeText(this@ActivityRiepilogoPag, "Errore durante il recupero dell'ID dell'utente", Toast.LENGTH_SHORT).show()
                    return
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                Log.e("OnFailure", t.toString())
                Toast.makeText(this@ActivityRiepilogoPag, "Errore nella risposta del server, riprova più tardi", Toast.LENGTH_SHORT).show()
            }
        })
    }


    private fun inserisciBiglietto(
        postiSelezionati: List<Posto>,
        dataProiezione: String,
        oraProiezione: String,
        titoloFilm: String,
        sala: Int,
        prezzoBiglietto: Double,
    ) {

        for (posto in postiSelezionati) {
            val fila = posto.fila
            val colonna = posto.colonna
            val chars = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
            val codiceBiglietto = (1..10).map { chars.random() }.joinToString("")
            val idUtenti = idUtentePagamento ?: return
            val query = "INSERT INTO webmobile.biglietti (data_proiezione, ora_inizio, fila, colonna, ref_film, ref_sala, prezzo, codice, ref_utente_b) " +
                    "VALUES ('$dataProiezione', '$oraProiezione', '$fila', '$colonna', '$titoloFilm',$sala, $prezzoBiglietto, '$codiceBiglietto', '$idUtenti')"
            RetrofitClient.retrofit.inserisciBiglietto(query).enqueue(object : Callback<JsonObject?> {
                override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@ActivityRiepilogoPag, "Inserimento nel database riuscito", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@ActivityRiepilogoPag, "Errore nell'inserimento nel database", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                    Log.e("OnFailure", t.toString())
                    Toast.makeText(this@ActivityRiepilogoPag, "Errore nella risposta del server, riprova piùtardi", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }
}