package com.francesco.cinema


import com.google.gson.JsonObject
import retrofit2.http.*
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Response

interface UserAPI {
    @POST("postInsert/")
    @FormUrlEncoded
    fun inserisciBiglietto(@Field("query") query: String): Call <JsonObject>

    @POST("postSelect/")
    @FormUrlEncoded
    fun login(@Field("query") query: String): Call <JsonObject>

    @POST("postInsert/")
    @FormUrlEncoded
    fun registrazione(@Field("query") query: String): Call <JsonObject>

    @POST("postSelect/")
    @FormUrlEncoded
    fun getDatiUtenti(@Field("query") query: String): Call<JsonObject>

    @POST("postRemove/")
    @FormUrlEncoded
    fun eliminaDati(@Field("query") query: String): Call <JsonObject>

    @POST("postSelect/")
    @FormUrlEncoded
    fun getIdUtente(@Field("query") query: String): Call <JsonObject>

    @POST("postUpdate/")
    @FormUrlEncoded
    fun modificaAccount(@Field("query") query: String): Call <JsonObject>

    @POST("postSelect/")
    @FormUrlEncoded
    fun verificaCredenziali(@Field("query") query: String): Call <JsonObject>

    @POST("postUpdate/")
    @FormUrlEncoded
    fun salvaPassword(@Field("query") query: String): Call <JsonObject>

    @POST("postInsert/")
    @FormUrlEncoded
    fun aggiungiCarta(@Field("query") query: String): Call <JsonObject>

    @POST("postSelect/")
    @FormUrlEncoded
    fun getCartaCredito(@Field("query") query: String): Call <JsonObject>

    @POST("postUpdate/")
    @FormUrlEncoded
    fun aggiornaStatoLogin(@Field("query") query: String): Call <JsonObject>






    @POST("postSelect/")
    @FormUrlEncoded
    fun select(@Field("query") query: String): Call <JsonObject>
    @POST("postUpdate/")
    @FormUrlEncoded
    fun update(@Field("query") query: String): Call <JsonObject>
    @POST("postRemove/")
    @FormUrlEncoded
    fun remove(@Field("query") query: String): Call <JsonObject>
    @POST("postInsert/")
    @FormUrlEncoded
    fun insert(@Field("query") query: String): Call <JsonObject>
    @GET
    fun image(@Url url: String) : Call <ResponseBody>

}