package com.francesco.cinema

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.Toast
import com.francesco.cinema.databinding.ActivityPasswordDimenticataBinding
//import androidx.databinding.DataBindingUtil
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class PasswordDimenticata : AppCompatActivity() {

    private lateinit var binding: ActivityPasswordDimenticataBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPasswordDimenticataBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnCambiaPass.setOnClickListener {
            val emailInserita = binding.emailEditText3.text.toString()
            val usernameInserito = binding.usernameEditText2.text.toString()

            verificaCredenziali(emailInserita, usernameInserito)
        }


    }

    private fun verificaCredenziali(email: String, username: String) {

        if (username.isEmpty()) {
            binding.usernameEditText2.error = "Campo obbligatorio"
            return
        }

        if (email.isEmpty()) {
            binding.emailEditText3.error =
                "Campo obbligatorio"
            return
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.emailEditText3.error = "Indirizzo email non valido"
            return
        }

        val query = "SELECT COUNT(*) as count FROM Utenti WHERE email = '$email' AND username = '$username'"

        RetrofitClient.retrofit.verificaCredenziali(query).enqueue(object : Callback<JsonObject?> {
            override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    val countArray = result?.getAsJsonArray("queryset")
                    Log.i("password dimenticata", "$result")
                    if (countArray != null && countArray.size() > 0) {
                        val countObject = countArray.get(0).asJsonObject
                        val count = countObject.get("count").asInt

                        if (count != null && count > 0) {
                            // Le credenziali corrispondono, mostra il fragment
                            val email = binding.emailEditText3.text.toString()
                            val fragment = CambiaPassFragment()
                            val bundle = Bundle().apply {
                                putString("email", email)
                            }
                            fragment.arguments = bundle
                            val transaction = supportFragmentManager.beginTransaction()
                            transaction.add(R.id.fragmentContainerView, fragment)
                            transaction.commit()
                            // Imposta la visibilità del contenitore del fragment su visibile
                            binding.fragmentContainerView.visibility = View.VISIBLE



                        } else {
                            Toast.makeText(this@PasswordDimenticata, "Credenziali non valide", Toast.LENGTH_SHORT).show()
                        }

                    }else {
                        Toast.makeText(this@PasswordDimenticata, "Risposta non valida dal server", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(this@PasswordDimenticata, "Errore durante la verifica delle credenziali", Toast.LENGTH_SHORT).show()
                }
            }

            override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                Log.e("OnFailure", t.toString())
                Toast.makeText(this@PasswordDimenticata, "Errore nella chiamata API", Toast.LENGTH_SHORT).show()
            }
        })
    }
}