package com.francesco.cinema

data class Ticket(
    val idTicket: Int,
    val data_proiezione: String,
    val ora_inizio: String,
    val fila: String,
    val colonna: String,
    val ref_film: String,
    val ref_sala: Int,
    val prezzo: Double,
    val codice: String
): java.io.Serializable