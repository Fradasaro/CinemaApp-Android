package com.francesco.cinema

import android.content.Intent
import android.graphics.BitmapFactory
import android.os.Bundle
import android.util.Log
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager
import com.francesco.cinema.databinding.ActivityPostoBinding
import com.google.gson.Gson
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class PostoActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPostoBinding
    private lateinit var userAPI: UserAPI
    private var ticketNumber = 1
    private var numBiglietti = 0
    private lateinit var proiezione: Proiezione
    val postiSelezionati = mutableListOf<Posto>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityPostoBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.textView11?.text = "Biglietto 1"


        // Recupera il numero di biglietti dall'extra dell'Intent
        numBiglietti = intent.getIntExtra("num_biglietti", 0)
         proiezione = intent.getSerializableExtra("Proiezione") as Proiezione


        val filaAdapter = ArrayAdapter.createFromResource(
            this,
            R.array.fila_options,
            android.R.layout.simple_spinner_item
        )
        filaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spnFila.adapter = filaAdapter

        val colonnaAdapter = ArrayAdapter.createFromResource(
            this,
            R.array.colonna_options,
            android.R.layout.simple_spinner_item
        )
        colonnaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spnColonna.adapter = colonnaAdapter

        userAPI = RetrofitClient.retrofit

        binding.chkPostoDisabili.setOnCheckedChangeListener { _, isChecked ->
            // Se la checkbox è selezionata, mostra solo la prima fila nello spinner della fila
            //supponiamo che la prima fila sia più accessibile a chi ha disabilità
            if (isChecked) {
                val filaAdapterDisabili = ArrayAdapter.createFromResource(
                    this,
                    R.array.fila_disabili_values,
                    android.R.layout.simple_spinner_item
                )
                filaAdapterDisabili.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
                binding.spnFila.adapter = filaAdapterDisabili
                binding.spnFila.setSelection(0)
            } else {
                binding.spnFila.adapter = filaAdapter
            }
        }

        binding.btnConferma.setOnClickListener {
            // Recupera i valori selezionati dall'interfaccia utente
            val filaValue = binding.spnFila.selectedItem.toString()
            val colonnaValue = binding.spnColonna.selectedItem.toString()
            val postoDisabiliValue = binding.chkPostoDisabili.isChecked


            val posto = Posto(filaValue, colonnaValue)

            postiSelezionati.add(posto)

            val sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
            val editor = sharedPreferences.edit()
            editor.putString("posti_selezionati", Gson().toJson(postiSelezionati))
            editor.apply()


            val query = "INSERT INTO webmobile.posto (fila, colonna, posti_disabili, ref_sala) " +
                    "VALUES ('$filaValue', '$colonnaValue', ${if (postoDisabiliValue) 1 else 0}, ${proiezione.ref_s})"

            userAPI.insert(query).enqueue(object : Callback<JsonObject> {
                override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                    if (response.isSuccessful) {
                        Toast.makeText(this@PostoActivity, "Prenotazione effettuata con successo!", Toast.LENGTH_SHORT).show()

                        ticketNumber++

                        if (ticketNumber > numBiglietti) {
                            val intent = Intent(this@PostoActivity, SnackBevandeActivity::class.java)
                            startActivity(intent)
                            finish() // Chiude questa Activity
                        } else {
                            binding.textView11?.text = "Biglietto $ticketNumber"
                            binding.spnFila.setSelection(0)
                            binding.spnColonna.setSelection(0)
                            binding.chkPostoDisabili.isChecked = false
                        }
                    } else {
                        Toast.makeText(this@PostoActivity, "Errore durante la prenotazione del posto", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                    Toast.makeText(this@PostoActivity, "Errore di connessione", Toast.LENGTH_SHORT).show()
                }
            })
        }
    }
}