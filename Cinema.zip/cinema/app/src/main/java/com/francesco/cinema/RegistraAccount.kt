package com.francesco.cinema

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.util.Patterns
import android.widget.Toast
import com.francesco.cinema.databinding.ActivityRegistraAccountBinding
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class RegistraAccount : AppCompatActivity() {

    private lateinit var binding: ActivityRegistraAccountBinding
    private var TAG = "prova"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegistraAccountBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.haiGiaAccText.setOnClickListener() {
            val i = Intent(this, PaginaLogin::class.java)
            startActivity(i)
        }





        binding.btnRegistati.setOnClickListener() {
            val username = binding.usernameEditText.text.toString()
            val email = binding.emailEditText.text.toString()
            val password = binding.passwordEditText.text.toString()

            if (username.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
                registraUtente(username, email, password)
                Toast.makeText(this, "Utente registato", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Inserisci username, email e password", Toast.LENGTH_SHORT).show()
            }

        }

    }

        private fun registraUtente(username: String, email: String, password: String) {

            if (username.isEmpty()) {
                binding.usernameEditText.error = "Campo obbligatorio"
                return
            }

            if (email.isEmpty()) {
                binding.emailEditText.error =
                    "Campo obbligatorio"
                return
            } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
                binding.emailEditText.error = "Indirizzo email non valido"
                return
            }

            if (password.isEmpty()) {
                binding.passwordEditText.error = "Campo obbligatorio"
                return
            } else if (password.length < 5) {
                binding.passwordEditText.error = "La password deve essere di almeno 5 caratteri"
                return
            }

            val confermaPassword = binding.confermaPassEditText.text.toString()
            if (confermaPassword != password) {
                binding.confermaPassEditText.error = "Le password non corrispondono"
                return
            }

            Log.i(TAG, "${email}, ${password}")
            val query ="INSERT INTO Utenti (username, email, password) VALUES ('$username','$email', '$password')"
            RetrofitClient.retrofit.registrazione(query).enqueue(object : Callback<JsonObject?> {
                override fun onResponse(call: Call<JsonObject?>, response: Response<JsonObject?>) {
                    if (response.isSuccessful) {
                        val intent = Intent(this@RegistraAccount, PaginaLogin::class.java)
                        startActivity(intent)
                    } else {
                        Toast.makeText(this@RegistraAccount, "Registrazione non riuscita", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onFailure(call: Call<JsonObject?>, t: Throwable) {
                    Log.e("OnFailure", t.toString())
                    Toast.makeText(this@RegistraAccount, "Errore nella risposta del server, riprova più tardi", Toast.LENGTH_SHORT).show()
                }
            })

        }
    }

