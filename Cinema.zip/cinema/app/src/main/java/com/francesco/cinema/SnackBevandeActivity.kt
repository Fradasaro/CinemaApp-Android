package com.francesco.cinema

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.francesco.cinema.databinding.SnackBevandeBinding
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class SnackBevandeActivity : AppCompatActivity() {

    private lateinit var snackBevandeAdapter: SnackBevandeAdapter
    private lateinit var binding: SnackBevandeBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = SnackBevandeBinding.inflate(layoutInflater)
        setContentView(binding.root)


        snackBevandeAdapter = SnackBevandeAdapter(this)

        binding.snackBevandaRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.snackBevandaRecyclerView.adapter = snackBevandeAdapter

        // Carica l'elenco di snack e bevande dal server
        loadSnackBevandeList()

        // Calcola e visualizza il totale del carrello iniziale
        val totaleCarrello = snackBevandeAdapter.calcolaTotaleCarrello()
        binding.totaleTextView.text = String.format("%.2f €", totaleCarrello)

        binding.aggiungiAlCarrelloButton.setOnClickListener {
            val totaleCarrello = snackBevandeAdapter.calcolaTotaleCarrello()

            val builder = AlertDialog.Builder(this)
            builder.setMessage("Il totale del carrello è di $totaleCarrello €. Vuoi procedere con l'acquisto?")
            builder.setPositiveButton("Vai al pagamento") { dialog, which ->

                var sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
                 sharedPreferences = this@SnackBevandeActivity.getSharedPreferences("prezzo_snack", Context.MODE_PRIVATE)
                val editor = sharedPreferences.edit()
                editor.putFloat("totaleCarrello", totaleCarrello.toFloat())
                editor.apply()
                val intent = Intent(this, LoginPagamento::class.java)

                startActivity(intent)




            }
            builder.setNegativeButton("Continua a comprare") { dialog, which ->
                // Qui non fai nulla, l'utente rimane nella SnackBevandeActivity
            }

            builder.show()
        }
        binding.noGrazieButton.setOnClickListener{
            val intent = Intent(this, LoginPagamento::class.java)

            startActivity(intent)
        }
    }

    private fun loadSnackBevandeList() {
        val userAPI: UserAPI = RetrofitClient.retrofit

        val query = "SELECT * FROM webmobile.snack_bevande"

        userAPI.login(query).enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    val jsonArray = result?.getAsJsonArray("queryset")
                    Log.d("SnackBevandeActivity", "Numero di snack e bevande: ${jsonArray?.size()}")
                    val snackBevandeList = mutableListOf<SnackBevande>()
                    jsonArray?.forEach { jsonObj ->
                        val snackBevande = SnackBevande(
                            idSnackBevande = jsonObj.asJsonObject.get("idsnack_bevande").asInt,
                            nome = jsonObj.asJsonObject.get("nome").asString,
                            prezzo = jsonObj.asJsonObject.get("prezzo").asDouble,
                            imgSB = jsonObj.asJsonObject.get("imgSB").asString
                        )
                        snackBevandeList.add(snackBevande)
                    }

                    // Verifica che la lista di snack e bevande sia stata caricata correttamente
                    Log.i("Response", "Snack e bevande caricate: $snackBevandeList")

                    // Aggiorna l'adattatore della RecyclerView con la nuova lista di snack e bevande
                    snackBevandeAdapter.updateSnackBevande(snackBevandeList)
                } else {
                    Log.d("SnackBevandeActivity", "Errore nella richiesta della lista di snack e bevande ${response.code()}")
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.d("SnackBevandeActivity", "Errore nella richiesta della lista di snack e bevande: ${t.message}")
            }
        })
    }

    fun aggiornaTotaleCarrello(totale: Double) {
        binding.totaleTextView.text = String.format("%.2f €", totale)
    }
}