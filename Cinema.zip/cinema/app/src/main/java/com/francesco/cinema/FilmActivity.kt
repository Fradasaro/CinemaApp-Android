package com.francesco.cinema

import android.content.ContentValues.TAG
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.drawable.BitmapDrawable
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.target.SimpleTarget
import com.francesco.cinema.databinding.ActivityFilmBinding
import com.google.gson.Gson
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

import com.google.gson.JsonObject
import com.google.gson.reflect.TypeToken
import kotlinx.coroutines.CoroutineScope
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response



class FilmActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFilmBinding
    private lateinit var filmList: List<Film>
    private lateinit var filmAdapter: FilmAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityFilmBinding.inflate(layoutInflater)
        setContentView(binding.root)

        filmList = intent.getSerializableExtra("Film") as List<Film>

        filmAdapter = FilmAdapter(filmList)

        binding.recyclerViewFilms.layoutManager = LinearLayoutManager(this@FilmActivity)
        binding.recyclerViewFilms.adapter = filmAdapter



        Log.e("FilmActivity", "Lista di film recuperata: ${filmList.size}")





        binding.recyclerViewFilms.addOnItemTouchListener(
            RecyclerItemClickListener(
                this@FilmActivity,
                object : RecyclerItemClickListener.OnItemClickListener {
                    override fun onItemClick(view: android.view.View, position: Int) {
                        // Recupera il film selezionato
                        val film = filmList[position]

                        val gson = Gson()
                        val filmJson = gson.toJson(film)

                        val intent = Intent(this@FilmActivity, FilmDetailsActivity::class.java)
                        intent.putExtra("film", filmJson)
                        startActivity(intent)
                    }
                })
        )
    }


}




