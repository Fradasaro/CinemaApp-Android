package com.francesco.cinema
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bumptech.glide.Glide
import com.francesco.cinema.databinding.ActivityFilmDetailsBinding
import com.google.gson.Gson
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FilmDetailsActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFilmDetailsBinding
    private lateinit var reviewAdapter: RecensioneAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFilmDetailsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerViewReviews.layoutManager = LinearLayoutManager(this)

        reviewAdapter = RecensioneAdapter(emptyList())

        binding.recyclerViewReviews.adapter = reviewAdapter

        val film = intent.getStringExtra("film")

        if (film != null) {
            val gson = Gson()
            val filmObject = gson.fromJson(film, Film::class.java)
            showFilmDetails(filmObject)
        }


    }

    private fun showFilmDetails(film: Film) {
        binding.filmTitleTextView.text = film.titolo

        binding.filmTramaContentTextView.text = film.trama

        Glide.with(this)
            .load(Constants.BASE_URL + film.img)
            .into(binding.filmPosterImageView)

        binding.filmCastContentTextView.text = film.cast

        binding.filmDurataContentTextView.text = film.durata + " min"

        // Carica la lista di recensioni nella RecyclerView
        loadReviewList(film.idFilm)
    }

    private fun loadReviewList(refFilm: Int) {
        val userAPI: UserAPI = RetrofitClient.retrofit

        val query = "SELECT * FROM webmobile.Recensioni WHERE ref_film = $refFilm"

        userAPI.login(query).enqueue(object : Callback<JsonObject> {
            override fun onResponse(call: Call<JsonObject>, response: Response<JsonObject>) {
                if (response.isSuccessful) {
                    val result = response.body()
                    val jsonArray = result?.getAsJsonArray("queryset")
                    Log.d("FilmDetailsActivity", "Numero di recensioni: ${jsonArray?.size()}")
                    val reviewList = mutableListOf<Recensione>()
                    jsonArray?.forEach { jsonObj ->
                        val recensione = Recensione(
                            idRecensione = jsonObj.asJsonObject.get("idRecensioni").asInt,
                            recensione = jsonObj.asJsonObject.get("recensione").asString,
                            recensore = jsonObj.asJsonObject.get("recensore").asString,
                            refFilm = jsonObj.asJsonObject.get("ref_film").asInt,
                            rating = jsonObj.asJsonObject.get("rating").asInt
                        )
                        reviewList.add(recensione)

                    }

                    Log.i("Response", "Recensioni caricate: $reviewList")

                    // Aggiorna l'adattatore della RecyclerView con la nuova lista di recensioni
                    reviewAdapter.updateRecensioni(reviewList)
                } else {
                    Log.d("FilmRepository", "Errore nella richiesta della lista di recensioni ${response.code()}")
                }
            }

            override fun onFailure(call: Call<JsonObject>, t: Throwable) {
                Log.d("FilmRepository", "Errore nella richiesta della lista di recensioni: ${t.message}")
            }
        })
    }
}