package com.francesco.cinema

data class SnackBevande(
    val idSnackBevande: Int,
    val nome: String,
    val prezzo: Double,
    val imgSB: String,
    var quantita: Int = 0
): java.io.Serializable