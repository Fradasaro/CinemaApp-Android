package com.francesco.cinema

object SessionManager {
    private var isLoggedIn: Boolean = false

    fun isLoggedIn(): Boolean {
        return isLoggedIn
    }

    fun setLoggedIn(value: Boolean) {
        isLoggedIn = value
    }
}