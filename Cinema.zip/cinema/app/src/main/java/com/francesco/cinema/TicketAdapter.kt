package com.francesco.cinema

import android.content.Context
import android.util.Log
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.francesco.cinema.databinding.ItemTicketBinding
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class TicketAdapter(private val context: Context) : RecyclerView.Adapter<TicketAdapter.TicketViewHolder>() {

    private var ticketList = mutableListOf<Ticket>()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TicketViewHolder {
        val binding = ItemTicketBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return TicketViewHolder(binding)
    }

    override fun onBindViewHolder(holder: TicketViewHolder, position: Int) {
        val ticket = ticketList[position]
        holder.bind(ticket)
    }

    override fun getItemCount(): Int {
        return ticketList.size
    }

    class TicketViewHolder(private val binding: ItemTicketBinding) : RecyclerView.ViewHolder(binding.root) {

        fun bind(ticket: Ticket) {
            binding.BigliettoFilmTextView.text = ticket.ref_film
            binding.BigliettoDataTextView.text = ticket.data_proiezione
            binding.BigliettoSalaTextView.text = "Sala " + ticket.ref_sala
            binding.BigliettoFilaTextView.text = ticket.fila
            binding.BigliettoColonnaTextView.text = ticket.colonna
            binding.BigliettoTimeTextView.text = ticket.ora_inizio
            binding.BigliettoCodeTextView.text = ticket.codice
            binding.BigliettoPrezzoTextView.text = ticket.prezzo.toString() + " €"
        }
    }

    fun updateTicket(newList: List<Ticket>) {
        ticketList.clear()
        ticketList.addAll(newList)
        notifyDataSetChanged()
    }

}