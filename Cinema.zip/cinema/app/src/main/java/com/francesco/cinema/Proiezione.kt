package com.francesco.cinema



data class Proiezione(
    val idProiezione: Int,
    val data_proiezione: String,
    val ora_inizio: String,
    val ref_f: Int,
    val ref_s: Int
): java.io.Serializable