package com.francesco.cinema

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.preference.PreferenceManager
import com.francesco.cinema.databinding.ActivityPagamentoBinding
import com.google.gson.JsonObject
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ActivityPagamento : AppCompatActivity() {

    private lateinit var binding: ActivityPagamentoBinding
    private val servizioPagamento: ServizioPagamento = ServizioPagamentoSimulato()



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPagamentoBinding.inflate(layoutInflater)
        setContentView(binding.root)




        val sharedPreferences = getSharedPreferences("DatiPagamento", Context.MODE_PRIVATE)
        val salvaDatiChecked = sharedPreferences.getBoolean("salvaDati", false)

        // Imposta lo stato della checkbox
        binding.checkBox.isChecked = salvaDatiChecked

        if (salvaDatiChecked) {
            val numCartaCredito = sharedPreferences.getString("numCartaCredito", "")
            val titolare = sharedPreferences.getString("titolare", "")
            val scadenza = sharedPreferences.getString("scadenza", "")
            val cvc = sharedPreferences.getString("cvc", "")

            binding.nCartaEditText.setText(numCartaCredito)
            binding.titolareEditText.setText(titolare)
            binding.scadenzaEditText.setText(scadenza)
            binding.CVCEditText.setText(cvc)
        }

        binding.checkBox.setOnCheckedChangeListener { _, isChecked ->
            // Se la checkbox viene selezionata, salva i dati
            if (isChecked) {
                val numCartaCredito = binding.nCartaEditText.text.toString()
                val titolare = binding.titolareEditText.text.toString()
                val scadenza = binding.scadenzaEditText.text.toString()
                val cvc = binding.CVCEditText.text.toString()
                // Salva i dati nelle SharedPreferences
                val editor = sharedPreferences.edit()
                editor.putString("numCartaCredito", numCartaCredito)
                editor.putString("titolare", titolare)
                editor.putString("scadenza", scadenza)
                editor.putString("cvc", cvc)
                editor.putBoolean("salvaDati", true)
                editor.apply()
            } else {
                // Se la checkbox viene deselezionata, rimuovi i dati salvati
                val editor = sharedPreferences.edit()
                editor.remove("numCartaCredito")
                editor.remove("titolare")
                editor.remove("scadenza")
                editor.remove("cvc")
                editor.remove("salvaDati")
                editor.apply()
            }
        }




        binding.btnPaga.setOnClickListener{
            Log.i("prova click", "Ho cliccato")

            val numCartaCredito = binding.nCartaEditText.text.toString()
            val titolare = binding.titolareEditText.text.toString()
            val scadenza = binding.scadenzaEditText.text.toString()
            val cvc = binding.CVCEditText.text.toString()
            val importo = sharedPreferences.getFloat("totale", 0.0F).toDouble()






            if (numCartaCredito.isEmpty() || titolare.isEmpty() || scadenza.isEmpty() || cvc.isEmpty()) {
                Toast.makeText(this@ActivityPagamento, "Inserisci tutti i campi", Toast.LENGTH_SHORT).show()
            } else {


                val risultatoPagamento = servizioPagamento.processoPagamento(importo,numCartaCredito, titolare, scadenza, cvc)

                if (risultatoPagamento) {
                    Toast.makeText(this@ActivityPagamento, "Pagamento elaborato con successo", Toast.LENGTH_SHORT).show()
                    val i = Intent(this@ActivityPagamento, MainActivity::class.java)
                    startActivity(i)
                    finish()

                } else {
                    Toast.makeText(this@ActivityPagamento, "Errore durante l'elaborazione del pagamento. Ricorda la carta di credito è di 16, mentre CVC di 3 e la data deve contenere /.", Toast.LENGTH_SHORT).show()
                }
            }
        }

    }










}
