package com.francesco.cinema

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import com.francesco.cinema.databinding.ActivityMainBinding
import com.google.gson.JsonArray
import com.google.gson.JsonObject
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var filmList: MutableList<Film>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Inizializza la lista di film come lista vuota
        filmList = mutableListOf()

        // Carica la lista di film dal server
        loadFilmList()

        binding.filmButton.setOnClickListener {
            val intent = Intent(this@MainActivity, FilmActivity::class.java)
            intent.putExtra("Film", filmList as java.io.Serializable)
            startActivity(intent)
        }

        binding.bigliettiButton.setOnClickListener {
            if (filmList.isNotEmpty()) {
                val intent = Intent(this@MainActivity, BigliettiActivity::class.java)
                intent.putExtra("FilmList", filmList as java.io.Serializable)
                startActivity(intent)
            }
        }

        binding.loginButton.setOnClickListener {
            val intent = Intent(this@MainActivity, PaginaLogin::class.java)
            startActivity(intent)
        }

        binding.btnInfo.setOnClickListener{
            val intent = Intent(this@MainActivity, ActivityInformazioni::class.java)
            startActivity(intent)
        }
    }

    private fun loadFilmList() {
        val userAPI: UserAPI = RetrofitClient.retrofit

        CoroutineScope(Dispatchers.IO).launch {
            try {
                // Avvia una coroutine per caricare la lista di film dal server
                val query = "SELECT * FROM webmobile.Film"
                val response = userAPI.login(query).enqueue(object : Callback<JsonObject?> {
                    override fun onResponse(
                        call: retrofit2.Call<JsonObject?>,
                        response: Response<JsonObject?>
                    ) {
                        if (response.isSuccessful) {
                            val result = response.body()
                            val querySet = result?.getAsJsonObject("querySet")
                            Log.i("Pippo", "$querySet")
                            Log.d("FilmRepository", "Lista di film recuperata: ${response.body()}")
                            val jsonArray = response.body()?.get("queryset") as JsonArray
                            jsonArray?.forEach { jsonObj ->
                                val film = Film(
                                    idFilm = jsonObj.getAsJsonObject().get("idFilm").asInt,
                                    titolo = jsonObj.getAsJsonObject().get("titolo").asString,
                                    cast = jsonObj.getAsJsonObject().get("cast").asString,
                                    durata = jsonObj.getAsJsonObject().get("durata").asString,
                                    trama = jsonObj.getAsJsonObject().get("trama").asString,
                                    img = jsonObj.getAsJsonObject().get("img").asString,
                                )
                                filmList.add(film)
                                Log.i("Dopo film.add", "img uguale a ${film.img}")

                            }

                        }
                    }

                    override fun onFailure(call: retrofit2.Call<JsonObject?>, t: Throwable) {
                        Toast.makeText(this@MainActivity, "onFailure", Toast.LENGTH_SHORT).show()
                    }
                })
            } catch (e: java.lang.Exception) {
                Log.i("Cetch", "Si è verificato il catch")
            }
        }
    }
}